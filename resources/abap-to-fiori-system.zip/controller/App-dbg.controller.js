sap.ui.define([
  "abap/to/fiori/system/controller/BaseController"
], function (BaseController) {
  "use strict";

  return BaseController.extend("abap.to.fiori.system.controller.App", {});
});
