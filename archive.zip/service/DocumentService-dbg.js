sap.ui.define([
  "abap/to/fiori/system/util/Constants"
], function (Constants) {
  "use strict";

  var MIME_TYPES = Object.freeze({
    X: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    P: "application/pdf",
    C: "text/csv;charset=utf-8",
    M: "text/markdown;charset=utf-8"
  });

  var EXTENSIONS = Object.freeze({
    X: "xlsx",
    P: "pdf",
    C: "csv",
    M: "md"
  });

  function DocumentService(oODataModel, mOptions) {
    this._oModel = oODataModel;
    this._mOptions = mOptions || {};
    this._bExportPollingCancelled = false;
  }

  DocumentService.prototype.buildExportPath = function (mParameters) {
    this._validateExportParameters(mParameters);

    return Constants.entitySet.exportResult +
      "(ReportType='" + this.escapeODataString(mParameters.reportType) +
      "',FileFormat='" + mParameters.fileFormat +
      "',ExportSection='" + mParameters.exportSection + "')/Content";
  };

  DocumentService.prototype.getExportMetadata = function (sFileFormat) {
    return {
      mimeType: this.getFallbackMimeType(sFileFormat),
      extension: EXTENSIONS[sFileFormat]
    };
  };

  DocumentService.prototype.downloadExport = function (mParameters) {
    var sFileFormat = mParameters && mParameters.fileFormat;
    var sUrl;
    var fnFetch;

    try {
      sUrl = this._buildAbsoluteExportUrl(mParameters);
    } catch (oValidationError) {
      return Promise.reject(oValidationError);
    }

    fnFetch = this._mOptions.fetch || window.fetch.bind(window);

    return fnFetch(sUrl, {
      method: "GET",
      credentials: "include",
      headers: {
        Accept: this.getFallbackMimeType(sFileFormat) || "*/*"
      }
    }).then(function (oResponse) {
      if (!oResponse.ok) {
        return this._readErrorResponse(oResponse).then(function (sMessage) {
          throw new Error(sMessage);
        });
      }

      return oResponse.blob().then(function (oBlob) {
        var sContentType = oResponse.headers && oResponse.headers.get("Content-Type");
        var sContentDisposition = oResponse.headers && oResponse.headers.get("Content-Disposition");
        var sMimeType = sContentType || this.getFallbackMimeType(sFileFormat);
        var sFileName = this._getFileNameFromContentDisposition(sContentDisposition) ||
          this.getFallbackFileName(mParameters);
        var oDownloadBlob = sMimeType && oBlob.type !== sMimeType ? oBlob.slice(0, oBlob.size, sMimeType) : oBlob;

        if (!oDownloadBlob || oDownloadBlob.size === 0) {
          throw new Error("The export response is empty.");
        }

        this._triggerDownload(oDownloadBlob, sFileName);
        return {
          fileName: sFileName,
          mimeType: sMimeType,
          url: sUrl
        };
      }.bind(this));
    }.bind(this));
  };

  DocumentService.prototype.prepareSelectedExport = function (sAnalysisId, mParameters) {
    var sId = String(sAnalysisId || "").trim();
    var oAction;
    var mActionParameters;

    this._validateSelectedExportParameters(mParameters);

    if (!sId) {
      return Promise.reject(new Error("AnalysisId is required for export."));
    }

    mActionParameters = this._buildSelectedExportActionParameters(mParameters);
    oAction = this._oModel.bindContext(
      Constants.entitySet.analyses + "(" + encodeURIComponent(sId) + ")/" + Constants.action.prepareSelectedExportSuffix
    );
    Object.keys(mActionParameters).forEach(function (sName) {
      oAction.setParameter(sName, mActionParameters[sName]);
    });

    return oAction.execute("$direct").then(function () {
      var oContext = oAction.getBoundContext && oAction.getBoundContext();
      return oContext && oContext.requestObject ? oContext.requestObject() : {};
    });
  };

  DocumentService.prototype.downloadSelectedExport = function (sAnalysisId, mParameters) {
    return this.prepareSelectedExport(sAnalysisId, mParameters).then(function (oResult) {
      if (oResult && oResult.DownloadUrl) {
        return this.downloadUrl(this._normalizeDownloadUrl(oResult.DownloadUrl), {
          fileName: this.getDownloadFileName(mParameters.fileName, oResult.FileName, mParameters.fileFormat),
          mimeType: oResult.MimeType,
          fileFormat: mParameters.fileFormat
        });
      }

      if (oResult && oResult.ExportId) {
        return this.pollExportJob(oResult.ExportId).then(function (oJob) {
          return this.downloadExportJobContent(oJob, {
            fileName: mParameters.fileName,
            fileFormat: mParameters.fileFormat
          });
        }.bind(this));
      }

      throw new Error("Export did not return a DownloadUrl or ExportId.");
    }.bind(this));
  };

  DocumentService.prototype.generateTechnicalDocument = function (sAnalysisId) {
    var sId = String(sAnalysisId || "").trim();
    var oAction;

    if (!sId) {
      return Promise.reject(new Error("AnalysisId is required for technical document generation."));
    }

    oAction = this._oModel.bindContext(
      Constants.entitySet.analyses + "(" + encodeURIComponent(sId) + ")/" + Constants.action.generateTechnicalDocumentSuffix
    );

    return oAction.execute("$direct").then(function () {
      var oContext = oAction.getBoundContext && oAction.getBoundContext();
      return oContext && oContext.requestObject ? oContext.requestObject() : {};
    });
  };

  DocumentService.prototype.downloadTechnicalDocument = function (sAnalysisId, mOptions) {
    var mDownloadOptions = mOptions || {};
    var sFileFormat = Constants.technicalDocument.fileFormat;

    return this.generateTechnicalDocument(sAnalysisId).then(function (oResult) {
      if (oResult && oResult.DownloadUrl) {
        return this.downloadUrl(this._normalizeDownloadUrl(oResult.DownloadUrl), {
          fileName: this.getDownloadFileName(mDownloadOptions.fileName, oResult.FileName, sFileFormat),
          mimeType: oResult.MimeType,
          fileFormat: sFileFormat
        });
      }

      if (oResult && oResult.ExportId) {
        return this.pollExportJob(oResult.ExportId).then(function (oJob) {
          return this.downloadExportJobContent(oJob, {
            fileName: mDownloadOptions.fileName,
            fileFormat: sFileFormat
          });
        }.bind(this));
      }

      throw new Error("Technical document generation did not return a DownloadUrl or ExportId.");
    }.bind(this));
  };

  DocumentService.prototype.serializeSelectedFields = function (aFieldKeys) {
    if (typeof aFieldKeys === "string") {
      return aFieldKeys;
    }
    return (aFieldKeys || []).join(",");
  };

  DocumentService.prototype._buildSelectedExportActionParameters = function (mParameters) {
    var mDefaults = Constants.exportDefaults || {};
    var bPdf = mParameters.fileFormat === Constants.fileFormat.pdf;
    var bExcel = mParameters.fileFormat === Constants.fileFormat.excel;
    var iFontSize = parseInt(mParameters.fontSize !== undefined ? mParameters.fontSize : mDefaults.fontSize, 10);

    if (isNaN(iFontSize)) {
      iFontSize = 10;
    }

    return {
      FileFormat: mParameters.fileFormat,
      ExportSection: mParameters.exportSection,
      SelectedFields: this.serializeSelectedFields(mParameters.selectedFields),
      PdfHeaderText: bPdf ? String(mParameters.pdfHeaderText !== undefined ? mParameters.pdfHeaderText : mDefaults.pdfHeaderText || "") : "",
      PdfFooterText: bPdf ? String(mParameters.pdfFooterText !== undefined ? mParameters.pdfFooterText : mDefaults.pdfFooterText || "") : "",
      PaperSize: bPdf ? String(mParameters.paperSize !== undefined ? mParameters.paperSize : mDefaults.paperSize || "A4") : "",
      Orientation: bPdf ? String(mParameters.orientation !== undefined ? mParameters.orientation : mDefaults.orientation || "P") : "",
      FontSize: bPdf ? iFontSize : 0,
      FitToPage: bPdf ? this._normalizeBoolean(mParameters.fitToPage, mDefaults.fitToPage) : false,
      SplitMultiValue: bExcel ? this._normalizeBoolean(mParameters.splitMultiValue, mDefaults.splitMultiValue) : false
    };
  };

  DocumentService.prototype._normalizeBoolean = function (vValue, bDefault) {
    var sValue;

    if (vValue === undefined || vValue === null) {
      return bDefault === true;
    }

    if (typeof vValue === "boolean") {
      return vValue;
    }

    sValue = String(vValue).trim().toUpperCase();
    return sValue === "TRUE" || sValue === "X" || sValue === "1" || sValue === "Y";
  };

  DocumentService.prototype.cancelExportPolling = function () {
    this._bExportPollingCancelled = true;
  };

  DocumentService.prototype.pollExportJob = function (sExportId) {
    var iTimeout = this._mOptions.exportTimeoutMs || 60000;
    var iInterval = this._mOptions.exportIntervalMs || 2000;
    var iStarted = Date.now();
    var fnSleep = this._mOptions.sleep || function (iMs) {
      return new Promise(function (resolve) {
        setTimeout(resolve, iMs);
      });
    };

    this._bExportPollingCancelled = false;

    function loop() {
      if (this._bExportPollingCancelled) {
        return Promise.reject(new Error("Export polling was cancelled."));
      }
      if (Date.now() - iStarted > iTimeout) {
        return Promise.reject(new Error("Export is still processing. Please try again later."));
      }
      return this.getExportJob(sExportId).then(function (oJob) {
        var sStatus = String(oJob && oJob.Status || "").toUpperCase();
        if (["READY", "COMPLETED", "SUCCESS"].indexOf(sStatus) !== -1) {
          return oJob;
        }
        if (["FAILED", "ERROR"].indexOf(sStatus) !== -1) {
          throw new Error(oJob.Message || "Export failed.");
        }
        return fnSleep(iInterval).then(loop.bind(this));
      }.bind(this));
    }

    return loop.call(this);
  };

  DocumentService.prototype.getExportJob = function (sExportId) {
    var sId = String(sExportId || "").trim();
    if (!sId) {
      return Promise.reject(new Error("ExportId is required."));
    }
    return this._oModel.bindContext(Constants.entitySet.exportJobs + "(" + encodeURIComponent(sId) + ")", undefined, {
      $select: "ExportId,AnalysisId,FileFormat,ExportSection,SelectedFields,Status,FileName,MimeType,Message,CreatedBy,CreatedAt,ExpiresAt",
      $$groupId: "$direct"
    }).requestObject();
  };

  DocumentService.prototype.downloadExportJobContent = function (oJob, mOptions) {
    var sExportId = oJob && oJob.ExportId;
    var sFileFormat = mOptions && mOptions.fileFormat || oJob && oJob.FileFormat;
    if (oJob && oJob.ExpiresAt && new Date(oJob.ExpiresAt).getTime() < Date.now()) {
      return Promise.reject(new Error("The export file has expired."));
    }
    return this.downloadUrl(this._buildAbsoluteServicePath(Constants.entitySet.exportJobs + "(" + encodeURIComponent(sExportId) + ")/Content"), {
      fileName: this.getDownloadFileName(mOptions && mOptions.fileName, oJob && oJob.FileName, sFileFormat),
      mimeType: oJob && oJob.MimeType,
      fileFormat: sFileFormat
    });
  };

  DocumentService.prototype.downloadUrl = function (sUrl, mOptions) {
    var fnFetch = this._mOptions.fetch || window.fetch.bind(window);
    var sFileFormat = mOptions && mOptions.fileFormat;

    return fnFetch(sUrl, {
      method: "GET",
      credentials: "include",
      headers: {
        Accept: mOptions && mOptions.mimeType || this.getFallbackMimeType(sFileFormat) || "*/*"
      }
    }).then(function (oResponse) {
      if (!oResponse.ok) {
        return this._readErrorResponse(oResponse).then(function (sMessage) {
          throw new Error(sMessage);
        });
      }
      return oResponse.blob().then(function (oBlob) {
        var sMimeType = mOptions && mOptions.mimeType || oResponse.headers && oResponse.headers.get("Content-Type") || this.getFallbackMimeType(sFileFormat);
        var sFileName = mOptions && mOptions.fileName || this._getFileNameFromContentDisposition(oResponse.headers && oResponse.headers.get("Content-Disposition")) || "export";
        var oDownloadBlob = sMimeType && oBlob.type !== sMimeType ? oBlob.slice(0, oBlob.size, sMimeType) : oBlob;

        if (!oDownloadBlob || oDownloadBlob.size === 0) {
          throw new Error("The export response is empty.");
        }

        this._triggerDownload(oDownloadBlob, this.sanitizeFileName(sFileName));
        return {
          fileName: this.sanitizeFileName(sFileName),
          mimeType: sMimeType,
          url: sUrl
        };
      }.bind(this));
    }.bind(this));
  };

  DocumentService.prototype.getFallbackFileName = function (mParameters) {
    var sReportType = this.sanitizeFileName(mParameters.reportType || "report");
    var sSection = this.sanitizeFileName(mParameters.exportSection || Constants.exportSection.all);
    var sExtension = EXTENSIONS[mParameters.fileFormat] || "bin";
    var oDate = this._mOptions.now ? this._mOptions.now() : new Date();
    var sTimestamp = this._formatTimestamp(oDate);

    return sReportType + "_" + sSection + "_" + sTimestamp + "." + sExtension;
  };

  DocumentService.prototype.getDownloadFileName = function (sPreferredFileName, sFallbackFileName, sFileFormat) {
    var sFileName = String(sPreferredFileName || "").trim() || String(sFallbackFileName || "").trim() || "export";

    return this.ensureFileExtension(sFileName, sFileFormat);
  };

  DocumentService.prototype.ensureFileExtension = function (sFileName, sFileFormat) {
    var sSanitized = this.sanitizeFileName(sFileName);
    var sExtension = EXTENSIONS[sFileFormat];

    if (!sExtension) {
      return sSanitized;
    }

    sSanitized = sSanitized.replace(/\.(xlsx|pdf|csv|md)$/i, "");
    return sSanitized + "." + sExtension;
  };

  DocumentService.prototype.getFallbackMimeType = function (sFileFormat) {
    return MIME_TYPES[sFileFormat] || "";
  };

  DocumentService.prototype.sanitizeFileName = function (sValue) {
    return String(sValue || "").replace(/[\/\\:*?"<>|]/g, "_").trim() || "report";
  };

  DocumentService.prototype.escapeODataString = function (sValue) {
    return String(sValue || "").replace(/'/g, "''");
  };

  DocumentService.prototype._validateExportParameters = function (mParameters) {
    var aFormats = Object.keys(Constants.fileFormat).map(function (sKey) {
      return Constants.fileFormat[sKey];
    });
    var aSections = Object.keys(Constants.exportSection).map(function (sKey) {
      return Constants.exportSection[sKey];
    });

    if (!mParameters || !String(mParameters.reportType || "").trim()) {
      throw new Error("Program name is required for export.");
    }

    if (aFormats.indexOf(mParameters.fileFormat) === -1) {
      throw new Error("Unsupported export file format.");
    }

    if (aSections.indexOf(mParameters.exportSection) === -1) {
      throw new Error("Unsupported export section.");
    }
  };

  DocumentService.prototype._validateSelectedExportParameters = function (mParameters) {
    this._validateExportParameters(Object.assign({
      reportType: "selected-export"
    }, mParameters || {}));

    if (String(mParameters.fileFormat || "").length > 1) {
      throw new Error("FileFormat must not exceed 1 character.");
    }

    if (String(mParameters.exportSection || "").length > 20) {
      throw new Error("ExportSection must not exceed 20 characters.");
    }

    if (mParameters.selectedFields !== undefined && typeof mParameters.selectedFields !== "string" && !Array.isArray(mParameters.selectedFields)) {
      throw new Error("SelectedFields must be a string or an array.");
    }

    if (mParameters.paperSize !== undefined && String(mParameters.paperSize).length > 10) {
      throw new Error("PaperSize must not exceed 10 characters.");
    }

    if (mParameters.orientation !== undefined && String(mParameters.orientation).length > 1) {
      throw new Error("Orientation must not exceed 1 character.");
    }

    if (mParameters.fileFormat === Constants.fileFormat.pdf && mParameters.fontSize !== undefined && (isNaN(parseInt(mParameters.fontSize, 10)) || parseInt(mParameters.fontSize, 10) <= 0)) {
      throw new Error("FontSize must be a positive integer.");
    }
  };

  DocumentService.prototype._buildAbsoluteServicePath = function (sPath) {
    var sServiceUrl = this._getServiceRoot();
    var iQueryIndex = sServiceUrl.indexOf("?");
    var sBase = iQueryIndex === -1 ? sServiceUrl : sServiceUrl.slice(0, iQueryIndex);
    var sQuery = iQueryIndex === -1 ? "" : sServiceUrl.slice(iQueryIndex + 1);
    var sValue = String(sPath || "");
    var iPathQueryIndex = sValue.indexOf("?");
    var sPathOnly = iPathQueryIndex === -1 ? sValue : sValue.slice(0, iPathQueryIndex);
    var sPathQuery = iPathQueryIndex === -1 ? "" : sValue.slice(iPathQueryIndex + 1);
    var aQueries = [];
    var sUrl = sBase.replace(/\/$/, "") + "/" + sPathOnly.replace(/^\//, "");

    if (sPathQuery) {
      aQueries.push(sPathQuery);
    }
    if (sQuery && sPathQuery.indexOf("sap-client=") === -1) {
      aQueries.push(sQuery);
    }

    return aQueries.length ? sUrl + "?" + aQueries.join("&") : sUrl;
  };

  DocumentService.prototype._normalizeDownloadUrl = function (sUrl) {
    var sValue = String(sUrl || "").trim();

    if (!sValue) {
      return sValue;
    }

    if (/^(https?:|blob:|data:)/i.test(sValue) || sValue.indexOf(Constants.service.root) === 0) {
      return sValue;
    }

    if (sValue.charAt(0) === "/" && sValue.indexOf("/sap/") !== 0) {
      return this._buildAbsoluteServicePath(sValue);
    }

    if (sValue.charAt(0) !== "/") {
      return this._buildAbsoluteServicePath(sValue);
    }

    return sValue;
  };

  DocumentService.prototype._buildAbsoluteExportUrl = function (mParameters) {
    var sServiceUrl = this._getServiceRoot();
    var sPath = this.buildExportPath(mParameters);
    var iQueryIndex = sServiceUrl.indexOf("?");
    var sBase = iQueryIndex === -1 ? sServiceUrl : sServiceUrl.slice(0, iQueryIndex);
    var sQuery = iQueryIndex === -1 ? "" : sServiceUrl.slice(iQueryIndex + 1);
    var sUrl = sBase.replace(/\/$/, "") + "/" + sPath.replace(/^\//, "");

    if (sQuery && sQuery.indexOf("sap-client=") !== -1) {
      return sUrl + "?" + sQuery;
    }

    if (sQuery) {
      return sUrl + "?" + sQuery + "&sap-client=" + encodeURIComponent(Constants.service.sapClient);
    }

    return sUrl + "?sap-client=" + encodeURIComponent(Constants.service.sapClient);
  };

  DocumentService.prototype._getServiceRoot = function () {
    if (this._oModel && typeof this._oModel.getServiceUrl === "function") {
      return this._oModel.getServiceUrl();
    }

    return Constants.service.root;
  };

  DocumentService.prototype._readErrorResponse = function (oResponse) {
    return oResponse.text().then(function (sText) {
      var sStatus = oResponse.status ? "HTTP " + oResponse.status : "HTTP error";
      var sMessage = sText;
      var oError;

      try {
        oError = JSON.parse(sText);
        sMessage = oError && oError.error && (
          oError.error.message && (oError.error.message.value || oError.error.message) ||
          oError.error.code
        );
      } catch (oParseError) {
        sMessage = sText;
      }

      return sMessage ? sStatus + ": " + sMessage : sStatus + ": Export failed.";
    });
  };

  DocumentService.prototype._getFileNameFromContentDisposition = function (sHeader) {
    var aMatch;
    var sFileName;

    if (!sHeader) {
      return "";
    }

    aMatch = /filename\*=UTF-8''([^;]+)/i.exec(sHeader);
    if (aMatch) {
      return this.sanitizeFileName(decodeURIComponent(aMatch[1]));
    }

    aMatch = /filename="?([^";]+)"?/i.exec(sHeader);
    sFileName = aMatch && aMatch[1];
    return sFileName ? this.sanitizeFileName(sFileName) : "";
  };

  DocumentService.prototype._triggerDownload = function (oBlob, sFileName) {
    var oUrlApi = this._mOptions.URL || window.URL;
    var oDocument = this._mOptions.document || window.document;
    var sObjectUrl = oUrlApi.createObjectURL(oBlob);
    var oAnchor = oDocument.createElement("a");

    try {
      oAnchor.href = sObjectUrl;
      oAnchor.download = sFileName;
      oAnchor.style.display = "none";
      oDocument.body.appendChild(oAnchor);
      oAnchor.click();
      oDocument.body.removeChild(oAnchor);
    } finally {
      oUrlApi.revokeObjectURL(sObjectUrl);
    }
  };

  DocumentService.prototype._formatTimestamp = function (oDate) {
    function pad(iValue) {
      return String(iValue).padStart(2, "0");
    }

    return oDate.getFullYear() +
      pad(oDate.getMonth() + 1) +
      pad(oDate.getDate()) + "_" +
      pad(oDate.getHours()) +
      pad(oDate.getMinutes()) +
      pad(oDate.getSeconds());
  };

  return DocumentService;
});
